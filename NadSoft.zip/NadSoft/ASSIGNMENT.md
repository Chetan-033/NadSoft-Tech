# Machine Test: Business Listing & Rating System

## Objective

Build a Business Listing & Rating System using Core PHP and MySQL.

This test evaluates:

- PHP (CRUD)
- MySQL database design
- jQuery + AJAX
- Bootstrap Modals
- Raty jQuery Plugin integration
- Clean code structure
- Real-time UI updates (No page refresh)

## Mandatory Tech Stack

- Core PHP (No framework)
- MySQL
- jQuery
- AJAX
- Bootstrap 4 or 5
- **Raty jQuery Plugin**  
  https://www.jqueryscript.net/demo/Full-featured-Star-Rating-Plugin-For-jQuery-Raty/

---

## Functional Requirements

### 1. Business Listing Page

Create a page that displays all businesses in a table format.

| Column        | Description                    |
|---------------|--------------------------------|
| ID            | Primary key                    |
| Business Name | Name of the business           |
| Address       | Business address               |
| Phone         | Contact phone                  |
| Email         | Contact email                  |
| Actions       | Add / Edit / Delete buttons    |
| Average Rating| Raty (Read Only)               |

### 2. Business CRUD (AJAX Based)

#### Add Business

- Open Bootstrap Modal
- Submit form via AJAX
- Insert record into database
- Update table dynamically
- No page refresh

#### Update Business

- Open Bootstrap Modal
- Pre-fill existing data
- Submit via AJAX
- Update row dynamically
- No page refresh

#### Delete Business

- Show confirmation dialog
- Delete via AJAX
- Remove row dynamically
- No page refresh

### 3. Rating System (Using Raty Plugin)

- Show average rating in table (Read-only mode)
- Support half-star rating (.5 allowed)
- Scale: 0 to 5
- **On Rating Click**: Open Rating Modal

### 4. Rating Modal Fields

- Name
- Email
- Phone
- Rating (Raty plugin – interactive)

### 5. Rating Logic

- **Rule 1:** If Email OR Phone already exists for the same business → Update existing rating
- **Rule 2:** If new user → Insert new rating record

### 6. Real-Time Update (Mandatory)

After rating submission:

- Recalculate average rating
- Update rating column instantly
- No page refresh

---

## Suggested Database Structure

### `businesses`

| Column     | Type        |
|------------|-------------|
| id (PK)    | INT         |
| name       | VARCHAR     |
| address    | TEXT        |
| phone      | VARCHAR     |
| email      | VARCHAR     |
| created_at | TIMESTAMP   |

### `ratings`

| Column      | Type        |
|-------------|-------------|
| id (PK)     | INT         |
| business_id (FK) | INT    |
| name        | VARCHAR     |
| email       | VARCHAR     |
| phone       | VARCHAR     |
| rating      | DECIMAL(2,1)|
| created_at  | TIMESTAMP   |

---

## Implementation Checklist

- [ ] Database created and tables set up
- [ ] Business listing page with table
- [ ] Add Business modal (Bootstrap + AJAX)
- [ ] Edit Business modal (pre-fill + AJAX)
- [ ] Delete Business (confirmation + AJAX)
- [ ] Raty plugin for average rating (read-only)
- [ ] Rating modal with Name, Email, Phone, Rating
- [ ] Rating logic (update if exists, insert if new)
- [ ] Real-time update after rating submit
