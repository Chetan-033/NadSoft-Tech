# Business Listing & Rating System

A CRUD-based business listing application with star ratings, built with Core PHP, MySQL, jQuery, Bootstrap, and the Raty jQuery plugin.

## Requirements

- PHP 7.4+ with PDO MySQL extension
- MySQL 5.7+ / MariaDB
- Apache/XAMPP (or any PHP server)

## Setup

### 1. Database

Create the database and tables:

```bash
mysql -u root -p < database.sql
```

Or run the SQL manually in phpMyAdmin:

1. Open phpMyAdmin (http://localhost/phpmyadmin)
2. Create database `nadsoft_business` or run the full `database.sql` script

### 2. Configuration

Edit `config/database.php` if your MySQL credentials differ:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'nadsoft_business');
define('DB_USER', 'root');
define('DB_PASS', '');
```

### 3. Run

With XAMPP:

1. Start Apache and MySQL
2. Open http://localhost/NadSoft/ in your browser

## Features

- **Business CRUD**: Add, Edit, Delete businesses via Bootstrap modals
- **AJAX**: All operations without page refresh
- **Ratings**: Star ratings (0–5, half-star) using Raty plugin
- **Rating Logic**: Update existing rating if email/phone matches, otherwise insert new
- **Real-time Updates**: Table updates dynamically after add, edit, delete, and rating submit

## Tech Stack

- PHP (Core, no framework)
- MySQL
- jQuery
- AJAX
- Bootstrap 5
- Raty jQuery Plugin
